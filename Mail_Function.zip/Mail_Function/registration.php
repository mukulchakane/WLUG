<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Register Online</title>

        <!-- CSS -->
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script> 
        <script src="js/jquery-1.10.2.js"></script>
        <script>
            $(function(){
            $("#footer").load("footer.html");
            });
        </script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/change.css">

        <link href="http://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <link href='https://fonts.googleapis.com/css?family=Rancho' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/footer-distributed-with-address-and-phones.css">
        <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">

        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="logo.ico">
    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand visible-phone" href="index.html"><img src="images/logo.png"/></a>
                    <a class="navbar-brand" href="index.html"><h4 class="h4W" style="padding:0px;">Walchand Linux Users' Group</h4>      
                        <h6 class="h6C">Community | Knowledge | Share</h6></a>

                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right pad">
                        <li><a href="index.html">Home</a></li>
                        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="events.html">Events<span class="caret"></span></a>
                      
                            <ul class="dropdown-menu" >
                                <li><a href="osday.html"  class="dropmenu">Open Source Day</a></li>
                                <li><a href="metamorphosis.html">Metamorphosis 2k15</a></li>
                                <li><a href="technotweet.html">Techno-Tweet 2k16</a></li>
                            </ul>
                        </li>
                        <li><a href="clubservices.html">Club Services</a></li>
                        <li><a href="member/members.html">Members</a></li>
                        <li><a href="gallery.html">Gallery</a></li>
                        <li><a href="aboutus.html">About Us</a></li>
                        <li><a href="contactus.php">Contact Us</a></li>

                    </ul>
                </div>
            </div>
        </nav>
        <br><br>
                <div class="container box-effect7">
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                        	<div class="form-top">
                    			<h3>Register Here</h3>
                    			<!--<marquee><h4>Android and Web development workshop entries are full.....!!!!!</h4></marquee>-->
                            </div>  
                            <div class="form-bottom">
			                    <form role="form" action="registration.php" method="post" data-toggle="validator">
			                    	<div class="form-group">
			                        	<label class="sr-only">Full Name</label>
			                        	<input type="text" name="name" placeholder="Fullname"  required class="form-control" id="contact-name">
			                        </div>
                                    <div class="form-group">
			                        	<label class="sr-only" for="contact-clg">College Name</label>
			                        	<input type="text" name="clg" placeholder="College name" required class="form-control" id="contact-clg">
			                        </div>
                                    
                                    <div class="form-group">
			                    		<label class="sr-only" for="contact-email">Email</label>
			                        	<input type="email" name="email" placeholder="Email" required  class="contact-email form-control" id="contact-email">
			                        </div>
   
			                        <div class="form-group">
			                        	<label class="sr-only" >Mobile No:</label>
			                        	<input type="text" maxlength="10" name="mob"  placeholder="Mobile No:" required class="form-control" id="mob">
			                        </div>
			                        <div class="form-group">
			                        	<label>Select Workshop</label>
                                        <select class="form-control" id="sel1" name="workshop" autofocus>
                                           <option value="android">Android</option>
                                            <option value="web">Web Development </option>
                                        </select>
                                    </div>
                                    
                                        <script>
                                            function transClick(opt)
                                            {
                                                var op_id=opt;
                                                switch(opt)
                                                {
                                                    case 1:
                                                        var txtId=document.getElementById("txtPaytm");
                                                        txtPaytm.disabled=false;
                                                        break;
                                                    case 2:
                                                        var txtID=document.getElementById("txtPaytm");
                                                        txtPaytm.disabled=true;
                                                        break;
                                                    default:
                                                        alert("Please choose the option for Online Transaction")
                                                        break;
                                                }
                                            }
                                        </script>
                                        
                                        
                                    <div class="form-group">
                                        <label>Online Transaction:</label>
                                        <input type="radio" data-toggle="collapse" data-target="#demo" name="tran" value="yes" onclick="transClick(1)">Yes
                                        <input type="radio" name="tran" data-toggle="collapse out" data-target="#demo" value="no" onclick="transClick(2)">No
                                        <div class="collapse out" id="demo">
                                        Click&nbsp;<a href="images/paytm.png" target="_blank">here</a>&nbsp;to know How to Transfer Money to Paytm Wallet ?
                                    
                                        <div class="form-group">
                                            <label>Paytm Transaction ID:</label>
                                            <input type="text" class="form-control" placeholder="Enter Your Transaction ID" name="tid" id="txtPaytm">
                                        
                                        </div>
                                            
                                    </div>  
                                        
                                    </div>
                            <script >
                                    
                                    $.('collapse').collapse();
                                    </script>
			                        <div class="form-group">
                                        <label data-toggle="collapse" data-target="#tid">Yes, I will carry My Laptop
                                            <input type="checkbox"  name="laptop" value="yes"/></label>
                                       		<div class="panel-collapse collapse" id="tid">
                                            <div class="panel-body">
                                        Laptop Configuration:(Required for Android Workshop)<br>
                                            1) Min 4GB RAM<br>
                                            2) Min i3 Processor<br>
                                            3) USB Cable<br>
                                            4) Android Mobile<br>
                                            5) Pendrive<br>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
			                                 <button type="submit" class="btn">Submit</button>
                                    </div>
			                    </form>
		                    </div>
                        </div>
                    </div>
                </div>  

<?php
//Receive form Data......
include "connect.php";
    //echo "Connected Successfully";
@$name = $_POST['name'];
@$clg = $_POST['clg'];
@$email = $_POST['email'];
@$mob = $_POST['mob'];
@$workshop = $_POST['workshop'];
@$tid = $_POST['tid'];
@$laptop = $_POST['laptop'];

if(!empty($name)&&!empty($clg)&&!empty($email)&&!empty($mob)&&!empty($workshop)){
   // echo "Data received...";

    if($connection && $_POST['tran']=="yes" &&!empty($tid)) {
     //Payment Information Is Provided..
        $query = "INSERT into registrationwithpayment VALUES ('','$name','$clg','$email','$mob','$workshop','$tid','$laptop')";
         $result = mysqli_query($connection,$query);
        if($result){
            echo " <div class=\"alert alert-success\" role=\"alert\">Request Successful , we will reach to you soon</div>";
            //Logic to send mail... Go to Mailsender class, sendmail function.
            include  "MailSender.php";
            include "config.php";
            $mailsender = new MailSender();
             $mailYTextBody = "Dear ". $name. "  ,".$REGISTRATION_WITH_PAYMENT . "\n Your Payment Details: Paytm Transaction Id :  " .$tid;

            $$result = $mailsender->sendMail($email,$name,$REGISTRATION_WITH_PAYMENT_SUBJECT,$mailYTextBody);
            if($result == 1){
                //email Message sent successfully
            }else{
                //email Message sending failed..
            }
        }
    }
    elseif($connection) {
        //Registered Without providing transaction Details
        $query = "INSERT into registrationwithoutpayment VALUES ('','$name','$clg','$email','$mob','$workshop','$laptop')";
        $result = mysqli_query($connection,$query);
        if($result){
            echo " <div class=\"alert alert-success\" role=\"alert\">Request Successful , we will reach to you soon</div>";
            //Logic to send mail... Go to Mailsender class, sendmail function.
            include  "MailSender.php";
            include "config.php";
            $mailsender = new MailSender();
             $mailYTextBody = "Dear ". $name . "  ,". $REGISTRATION_WITHOUT_PAYMENT;
            $$result = $mailsender->sendMail($email,$name,$REGISTRATION_WITHOUT_PAYMENT_SUBJECT,$mailYTextBody);
            if($result == 1){
                //email Message sent successfully
            }else{
                //email Message sending failed..
            }
        }
    }
}else{
     "<div class=\"alert alert-danger\" role=\"alert\">Fields should not be empty, Please feel details...!!!</div>";
}
?>     
   <div id="footer"></div>
       <script>$('ul.nav li.dropdown').hover(function() {
    $(this).find('.dropdown-menu').stop(true, true).delay(20).fadeIn(200);
    }, function() {
    $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });</script>
    </body>
</html>
