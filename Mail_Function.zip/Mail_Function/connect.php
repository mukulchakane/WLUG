
<?php
$servername="182.50.133.85:3306";
$username="wlug";
$pass="WLUGadmin@123";
$mydbname="wlug";

$connection = mysqli_connect($servername , $username , $pass , $mydbname);
?>
