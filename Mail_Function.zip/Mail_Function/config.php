<?php

$CONTACT_US_MESSAGE_TEXT = "Thank you , for  reaching to Walchand Linux Users' Group , your response has been recorded, and its valuable for us. Thank you again for feedback.";
$CONTACT_US_SUBJECT = "Received Message, Walchand Linux Users' Group";

$REGISTRATION_WITHOUT_PAYMENT_SUBJECT = "Registration for Technotweet2k16, WLUG, 19-20 March 2016";
$REGISTRATION_WITHOUT_PAYMENT = "Thank You for registering at TECHNO-TWEET 2k16 that will be conducted by Walchand Linux Users' Group at WCE, Sangli on 19-20 March 2016.. Please remember that your registration will not be confirmed until you pay for event, kindly pay using PAYTM wallet on WCE WLUG paytm no: +91-9096233309  and fill the payment details @ www.wcewlug.org/registration.php Or wait till our coordinators reach at you. ";

$REGISTRATION_WITH_PAYMENT_SUBJECT = "Registration for Technotweet2k16, WLUG, 19-20 March 2016";
$REGISTRATION_WITH_PAYMENT = "Thank You for registering at TECHNO-TWEET 2k16, that will be conducted by Walchand Linux Users' Group at WCE, Sangli, on 19-20 March 2016 Your payment information is under review of Finance Team , once it get confirmed , you will get confirmation mail from our side.";

?>